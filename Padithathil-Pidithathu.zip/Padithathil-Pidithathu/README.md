# -
A 'Force Directed Graph'  using D3 Js is created for 25 episodes of 'படித்ததில் பிடித்தது' (Those I read and I liked!) where literary celebrities share and recommend 4 to 5 books every episode.  
